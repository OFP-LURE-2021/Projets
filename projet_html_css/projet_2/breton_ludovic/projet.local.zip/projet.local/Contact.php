<?php
    $serveur = "localhost"; $dbname = "Projet"; $user = "Ludovic"; $pass = "Breton.1505";
    
    $name = valid_donnees($_POST["name"]);
    $email = valid_donnees($_POST["email"]);
    $message = valid_donnees($_POST["message"]);
    
    function valid_donnees($donnees){
        $donnees = trim($donnees);
        $donnees = stripslashes($donnees);
        $donnees = htmlspecialchars($donnees);
        return $donnees;
    }
    
    /*Si les champs prenom et mail ne sont pas vides et si les donnees ont
     *bien la forme attendue...*/
    if (!empty($name)
        && strlen($name) <= 20
        && !empty($email)
        && filter_var($email, FILTER_VALIDATE_EMAIL)){
    
        try{
            //On se connecte à la BDD
            $dbco = new PDO("mysql:host=$eerveur;dbname=$dbname",$user,$pass);
            $dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            //On insère les données reçues
            $sth = $dbco->prepare("
                INSERT INTO Formulaire(name, email, message)
                VALUES(:name, :email, :message)");
            $sth->bindParam(':name',$name);
            $sth->bindParam(':email',$email);
            $sth->bindParam(':message',$message);            
            $sth->execute();
            //On renvoie l'utilisateur vers la page de remerciement
            header("Location:Message_envoyé.html");
        }
        catch(PDOException $e){
            echo 'Erreur : '.$e->getMessage();
        }
    }else{
        header("Location:Nous_contacter.php");
    }
?>