<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<title>Recette Thermomix</title>
	<link rel="stylesheet" type="text/css" href="Siteconvertisseurderecette.css">
</head>
<body>
	<nav>
			<div class="conteneur_nav">
				<label for="mobile">Menu</label>
				<input type="checkbox" id="mobile" role="button">
				<ul>
					<li class="deroulant"><a href="#">Convertisseur &ensp;</a>
						<ul class="sous">
							<li> <a href="Votre_convertisseur.php">Convertisseur Thermomix</a> </li>
							<li> <a href="Votre_convertisseur2.php">Convertisseur Magimix</a> </li>
							<li> <a href="Votre_convertisseur3.php">Convertisseur Cookeo</a> </li>
						</ul>
					</li>
					<li> <a href="Accueil.php">Accueil</a> </li>
					<li> <a href="Qui_nous_sommes.php">Qui nous sommes</a> </li>
					<li> <a href="Nous_contacter.php">Contact</a> </li>
					<li>
						<form action="verification.php" method="POST">
							<a href="#">Connexion</a>
								<ul class="sous">
                                	<li>
               							<input type="text" placeholder="Nom d'utilisateur" name="username" required class="log2">
               						</li>
                					<li>
                						<input type="password" placeholder="Mot de passe" name="password" required class="log2">
                					</li>
                					<li>
                						<input type="submit" id='submit' value='Se connecter' >
                					</li>
                					<li>
                						<a href="inscription.php"><span class="enregistrement">S'enregistrer</span></a>
                					</li>
                				</ul>      	
            			</form>
            		</li>	
				</ul>
			</div>	
		</nav>

</body>
</html>