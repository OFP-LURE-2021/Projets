<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<title>Vous inscrire</title>
	<link rel="stylesheet" type="text/css" href="Siteconvertisseurderecette.css">
</head>
<body>
	<header>
		<img class="imginscri" src="images/inscriptions.jpg">
	</header>
	<nav>
		<div class="conteneur_nav">
			<label for="mobile">Menu</label>
			<input type="checkbox" id="mobile" role="button">
			<ul>
				<li class="deroulant"><a href="#">Convertisseur &ensp;</a>
					<ul class="sous">
						<li> <a href="Votre_convertisseur.php">Convertisseur Thermomix</a> </li>
						<li> <a href="Votre_convertisseur2.php">Convertisseur Magimix</a> </li>
						<li> <a href="Votre_convertisseur3.php">Convertisseur Cookeo</a> </li>
					</ul>
				</li>
				<li> <a href="Accueil.php">Accueil</a> </li>
				<li> <a href="Qui_nous_sommes.php">Qui nous sommes</a> </li>
				<li> <a href="Nous_contacter.php">Contact</a> </li>
				<li>
					<form action="verification.php" method="POST">
						<a href="#">Connexion</a>
							<ul class="sous">
                                <li>
               						<input type="text" placeholder="Nom d'utilisateur" name="username" required class="log2">
               					</li>
                				<li>
                					<input type="password" placeholder="Mot de passe" name="password" required class="log2">
                				</li>
                				<li>
                					<input type="submit" id='submit' value='Se connecter' >
                				</li>
                				<li>
                					<a href="inscription.php"><span class="enregistrement">S'enregistrer</span></a>
                				</li>
                			</ul>      	
            		</form>
            	</li>		
			</ul>
		</div>	
	</nav>
	<h2 class="inscription">Formulaire d'enregistrement</h2>
	<form class="inscription" method="POST" action="enregistrement.php">
		<p>
       		<label for="pseudo">Votre pseudo :</label>
       		<input type="text" name="pseudo" id="pseudo" placeholder="Votre pseudo" maxlength="15" required />
       	</p>
       	<p>	
       		<label for="password">Votre mots de passe :</label>
       		<input type="password" id="password" class="password" placeholder="Mettre votre mots de passe" minlength="8" required />
       	</p>
       	<p>
       		<label for="confpassword">Confirmation mots de passe :</label>
       		<input type="password" id="confpassword" class="password" placeholder="Mettre le même mots de passe" minlength="8" required />  		
       	</p>
		<p>
			<label for="email">Votre email :</label>
			<input type="email" name="email" id="email" required />
		</p>
		<p>
			<label for="confemail">Confirmation email :</label>
			<input type="email" name="email" id="confemail" required />
		</p>
		<p>
			<input type="submit" value="S'enregistrer">
		</p>
	</form>
	<footer>
		<hr>
		<p>Copyright Breton/Muru 2021</p>
	</footer>

</body>
</html>