<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>Qui nous sommes</title>
		<link rel="stylesheet" type="text/css" href="Siteconvertisseurderecette.css">
		<script src="Site_convertisseur_de_recette.js" async></script>
	</head>
		<body>
			<div><img class="img2" src="images/About_us.jpg" alt="Qui_nous_sommes"></div>			
			<nav>
				<div class="conteneur_nav">
					<label for="mobile">Menu</label>
					<input type="checkbox" id="mobile" role="button">
					<ul>
						<li class="deroulant"><a href="#">Convertisseur &ensp;</a>
							<ul class="sous">
								<li> <a href="Votre_convertisseur.php">Convertisseur Thermomix</a> </li>
								<li> <a href="Votre_convertisseur2.php">Convertisseur Magimix</a> </li>
								<li> <a href="Votre_convertisseur3.php">Convertisseur Cookeo</a> </li>
							</ul>
						</li>
						<li> <a href="Accueil.php">Accueil</a> </li>
						<li> <a href="Qui_nous_sommes.php">Qui nous sommes</a> </li>
						<li> <a href="Nous_contacter.php">Contact</a> </li>
						<li>
							<form action="verification.php" method="POST">
								<a href="#">Connexion</a>
									<ul class="sous">
                                		<li>
               								<input type="text" placeholder="Nom d'utilisateur" name="username" required class="log2">
               							</li>
                						<li>
                							<input type="password" placeholder="Mot de passe" name="password" required class="log2">
                						</li>
                						<li>
                							<input type="submit" id='submit' value='Se connecter' >
                						</li>
                						<li>
                							<a href="inscription.php"><span class="enregistrement">S'enregistrer</span></a>
                						</li>
                					</ul>      	
            				</form>
            			</li>		
					</ul>
				</div>	
			</nav>
			<h1 tabindex="0" >Qui nous sommes</h1>
			<p class="qui">Nous sommes avant toute chose des passionnés de nourriture que cela soit salé, sucré, d'europe, d'asie, latine ou autres.
			</p>
				<section class="cards">
					<div class="cards__single">			
						<div class="cards__front">
							<h2>Mélanie</h2>
							<img class="img4" src="images/card.jpg" alt="image de macarons">								
						</div>
						<div class="cards__back">
							Mélanie est diététicienne de formation, elle adore les plats du monde en général et encore plus les pâtisseries.
						</div>
					</div>
					<div class="cards__single">
						<div class="cards__front">
							<h2>Ludovic</h2>
							<img class="img5" src="images/card1.jpg" alt="image de sushis">							
						</div>
						<div class="cards__back">
							Ludovic est cuisinier de formation, il a travaillé en cuisine collective la plupart du temps et connaît donc le système des variocooking qui est l'équivalent des Thermomix, Magimix ou cookeo mais en plus grande quantité.<br>
							Vous pouvez d'ailleurs voir un variocooking lors de la finale Topchef saison 12 quand Momo fait sa sauce.
						</div>
					</div>					
				</section>
				<p class="qui">	
					Nous avons chez nous un Thermomix, mais même si nous possédons l'application Cookidoo, nous avons trouvé qu'il était dommage de ne pas pouvoir prendre une recette X ou Y et la transformer directement en recette Thermomix.<br> 
					Nous nous lançons donc dans la création d'un site dans un premier temps permettant de convertir les recettes de n'importe quel site en recette de vos appareils. Il y aura forcément des loupés et nous nous en excusons d'avance et nous travaillerons à rectifier le tir.	
				</p>				
			<footer>
			<hr>
			<p>Copyright Breton/Muru 2021</p>
		</footer>
		</body>
</html>