<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>Convertisseur Magimix</title>
		<link rel="stylesheet" type="text/css" href="Siteconvertisseurderecette.css">
		<script src="Site_convertisseur_de_recette.js" async></script>
	</head>
	<body>
		<header>
			<img src="images/Magimix.jpg" alt="Magimix">
			<h1>Votre convertisseur Magimix</h1>
				<p>Vous trouverez prochainement le convertisseur <strong>Magimix</strong></p>
		</header>		
		<nav>
			<div class="conteneur_nav">
				<label for="mobile">Menu</label>
				<input type="checkbox" id="mobile" role="button">
				<ul>
					<li class="deroulant"><a href="#">Convertisseur &ensp;</a>
						<ul class="sous">
							<li> <a href="Votre_convertisseur.php">Convertisseur Thermomix</a> </li>
							<li> <a href="Votre_convertisseur2.php">Convertisseur Magimix</a> </li>
							<li> <a href="Votre_convertisseur3.php">Convertisseur Cookeo</a> </li>
						</ul>
					</li>
					<li> <a href="Accueil.php">Accueil</a> </li>
					<li> <a href="Qui_nous_sommes.php">Qui nous sommes</a> </li>
					<li> <a href="Nous_contacter.php">Contact</a> </li>
					<li>
						<form action="verification.php" method="POST">
							<a href="#">Connexion</a>
								<ul class="sous">
                                	<li>
               							<input type="text" placeholder="Nom d'utilisateur" name="username" required class="log2">
               						</li>
                					<li>
                						<input type="password" placeholder="Mot de passe" name="password" required class="log2">
                					</li>
                					<li>
                						<input type="submit" id='submit' value='Se connecter' >
                					</li>
                					<li>
                						<a href="inscription.php"><span class="enregistrement">S'enregistrer</span></a>
                					</li>
                				</ul>      	
            			</form>
            		</li>		
				</ul>
			</div>	
		</nav>
		<section>
			<table id="tableau">
				<thead>
					<tr>
						<th id="ingredient">Ingrédient</th>
						<th id="Unites_de_mesure">Unités de mesure</th>
						<th id="Quantite">Quantité</th>
						<th id="supprimerLigne"></th>	
					</tr>
				</thead>
				<tbody id="tbody">		
					<tr>	
						<td><input type="text" placeholder="votre ingrédient" class="ingredient"></td>
						<td><select name="Unités" class="Unités" >
    						<option value="">--Choisir l'unité de mesure--</option>
    						<option value="g">g</option>
    						<option value="kg">kg</option>
    						<option value="ml">ml</option>
    						<option value="cl">cl</option>
    						<option value="dl">dl</option>
    						<option value="litre">litre</option>
    						</select></td>
    					<td><input type="text" class="Quantité"></td>
    					<td ><img class="img3" src="images/Poubelle.jpg" onclick="deleteRow(this)" alt="supprimer ligne"></td>	
    				</tr>
    				<tr>	
						<td><input type="text" placeholder="votre ingrédient" class="ingredient"></td>
						<td><select name="Unités" class="Unités" >
    						<option value="">--Choisir l'unité de mesure--</option>
    						<option value="g">g</option>
    						<option value="kg">kg</option>
    						<option value="ml">ml</option>
    						<option value="cl">cl</option>
    						<option value="dl">dl</option>
    						<option value="litre">litre</option>
    						</select></td>
    					<td><input type="text" class="Quantité"></td>
    					<td ><img class="img3" src="images/Poubelle.jpg" onclick="deleteRow(this)" alt="supprimer ligne"></td>	
    				</tr>
    				<tr>	
						<td><input type="text" placeholder="votre ingrédient" class="ingredient"></td>
						<td><select name="Unités" class="Unités" >
    						<option value="">--Choisir l'unité de mesure--</option>
    						<option value="g">g</option>
    						<option value="kg">kg</option>
    						<option value="ml">ml</option>
    						<option value="cl">cl</option>
    						<option value="dl">dl</option>
    						<option value="litre">litre</option>
    						</select></td>
    					<td><input type="text" class="Quantité"></td>
    					<td ><img class="img3" src="images/Poubelle.jpg" onclick="deleteRow(this)" alt="supprimer ligne"></td>	
    				</tr>
    			</tbody>
    			<tfoot class="tfoot">
    				<tr>
    					<td colspan="3"><input type="button" value="Ajouter un ingrédient" onclick="ajouterLigne()" />	</td>
    				</tr>
    				<tr>	
    					<td colspan="3">
    						<form action="Etape_recette_Thermomix.html">
    							<button type="submit">Valider</button>
    						</form>
    					</td>
    				</tr>	
    			</tfoot>
			</table>
		</section>
		<footer>
			<hr>
			<p>Copyright Breton/Muru 2021</p>
		</footer>
	</body>
</html>