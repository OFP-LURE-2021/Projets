<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>Nous contacter</title>
		<link rel="stylesheet" type="text/css" href="Siteconvertisseurderecette.css">
	</head>
	<header>
			<img class="img1" src="images/Contact.jpg" alt="Contact">
			<h1>Nous contacter</h1>
	</header>
	<body>		
		<nav>
			<div class="conteneur_nav">
				<label for="mobile">Menu</label>
				<input type="checkbox" id="mobile" role="button">
				<ul>
					<li class="deroulant"><a href="#">Convertisseur &ensp;</a>
						<ul class="sous">
							<li><a href="Votre_convertisseur.php">Convertisseur Thermomix</a></li>
							<li><a href="Votre_convertisseur2.php">Convertisseur Magimix</a></li>
							<li><a href="Votre_convertisseur3.php">Convertisseur Cookeo</a></li>
						</ul>
					</li>
					<li><a href="Accueil.php">Accueil</a></li>
					<li><a href="Qui_nous_sommes.php">Qui nous sommes</a></li>
					<li><a href="Nous_contacter.php">Contact</a></li>
					<li>
						<form action="verification.php" method="POST">
							<a href="#">Connexion</a>
								<ul class="sous">
                                	<li>
               							<input type="text" placeholder="Nom d'utilisateur" name="username" required class="log2">
               						</li>
                					<li>
                						<input type="password" placeholder="Mot de passe" name="password" required class="log2">
                					</li>
                					<li>
                						<input type="submit" id='submit' value='Se connecter' >
                					</li>
                					<li>
                						<a href="inscription.php"><span class="enregistrement">S'enregistrer</span></a>
                					</li>
                				</ul>      	
            			</form>
            		</li>		
				</ul>
			</div>	
		</nav>
		<form class="formulaire" method="post" action="Contact.php">
    		<div>
        		<label for="name">Nom :</label>
        		<input type="text" id="name" name="name" placeholder="Votre nom" required pattern="^[A-Za-z '-]+$" autocomplete>
    		</div>
    		<div>
        		<label for="email">e-mail :</label>
        		<input type="email" id="email" name="email" placeholder="Votre adresse mail" required pattern="^[A-Za-z]+@{1}[A-Za-z]+\.{1}[A-Za-Z]{2,}$" autocomplete>
    		</div>
    		<div>
        		<label for="message">Message :</label>
        		<textarea id="message" name="message" placeholder="Veuillez écrire ici votre message, 2000 caractéres maximum" maxlength="2000" required></textarea>
    		</div>
    		<div class="button" id="submit">
        		<input type="submit" value="Envoyer le message">
        	</div>
    		</div>
		</form>
		<footer>
			<hr>
			<p>Copyright Breton/Muru 2021</p>
		</footer>		
	</body>
</html>